class AdminController < ApplicationController

  before_action :require_admin

  def index
    @candidates = Candidate.all
  end

  private

  def require_admin
    user = User.find(session[:user_id])
    redirect_to candidates_path unless user.role == "admin"
  end

end