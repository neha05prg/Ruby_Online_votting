class CandidatesController < ApplicationController

  # Only admin can create, edit, update, delete
  before_action :require_admin, only: [:new, :create, :edit, :update, :destroy]

  def index
    @candidates = Candidate.all

    if session[:user_id]
      @has_voted = Vote.exists?(user_id: session[:user_id])

      user = User.find(session[:user_id])
      @is_admin = user.role == "admin"
    else
      @has_voted = false
      @is_admin = false
    end
  end

  def new
    @candidate = Candidate.new
  end

  def create
    @candidate = Candidate.new(candidate_params)

    if @candidate.save
      redirect_to candidates_path
    else
      render :new
    end
  end

  def edit
    @candidate = Candidate.find(params[:id])
  end

  def update
    @candidate = Candidate.find(params[:id])

    if @candidate.update(candidate_params)
      redirect_to candidates_path
    else
      render :edit
    end
  end

  def destroy
    @candidate = Candidate.find(params[:id])
    @candidate.destroy
    redirect_to candidates_path
  end

  private

  def candidate_params
    params.require(:candidate).permit(:name, :image)
  end

  def require_admin
    if session[:user_id].nil?
      redirect_to login_path, alert: "Please login first"
      return
    end

    user = User.find(session[:user_id])

    unless user.role == "admin"
      redirect_to candidates_path, alert: "Not authorized"
    end
  end

end