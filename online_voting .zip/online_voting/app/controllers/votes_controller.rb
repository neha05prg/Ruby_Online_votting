class VotesController < ApplicationController

  def create
    user = User.find(session[:user_id])

    # ❌ Admin cannot vote
    if user.role == "admin"
      redirect_to candidates_path, alert: "Admin cannot vote"
      return
    end

    @vote = Vote.new(
      user_id: user.id,
      candidate_id: params[:candidate_id]
    )

    if @vote.save
      redirect_to candidates_path
    else
      redirect_to candidates_path, alert: "You already voted"
    end
  end

end