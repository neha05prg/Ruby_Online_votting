class Candidate < ApplicationRecord
  has_many :votes, dependent: :destroy
  has_one_attached :image
end