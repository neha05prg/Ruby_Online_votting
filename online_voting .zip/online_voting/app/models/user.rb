class User < ApplicationRecord
  has_secure_password

  has_many :votes
  has_many :candidates, through: :votes

  validates :email, presence: true, uniqueness: true
end