Rails.application.routes.draw do
  root "sessions#new"

  resources :users
  resources :candidates
  resources :votes

  get "login", to: "sessions#new"
  get "admin", to: "admin#index"
  post "login", to: "sessions#create"
  delete "logout", to: "sessions#destroy"
end