class AddImageToCandidates < ActiveRecord::Migration[8.1]
  def change
    add_column :candidates, :image, :string
  end
end
